void main() {
  
  //Parte do Programa que calcula a área de um circulo.
  var raio = 150;
  var area = 3.141592653 * (raio * raio);
  
  print('A area do circulo com o raio de valor $raio é igual a ${area.toStringAsFixed(4)}.');
  
  //Parte do Programa que calcula o Salario de um funcionario.
  var chapa = 1;
  var horasTrabalhadas = 200;
  var valorPorHora = 20.50;
  var salario = horasTrabalhadas * valorPorHora;
  
  print('O salario do funcionario $chapa, é igual a ${salario.toStringAsFixed(2)} reais.');
  
  //Parte do Programa que Calula o salario de um funcionario mais a sua comissão na empresa.
  var nome = "João";
  var salario2 = 500;
  var vendasDoMes = 1230;
  var salarioComComissao = salario2 + (vendasDoMes * 15 / 100 );
  
  print('O salario do mes de $nome é igual a ${salarioComComissao.toStringAsFixed(2)} reais.');
 
  //Parte do Programa que calcula o resultado de uma equação da primeira lei da termodinâmica.
  var energiaRecebida = 50;
  var energiaDoTrabalho = 12;
  var energiaInterna = 100;
  var energiaFinal = energiaInterna + energiaRecebida - energiaDoTrabalho;
  
  print('O resultado final da equação da 1° lei da termodinâmica é $energiaFinal\J.');
  
  //Parte do Programa que calcula o resultado da capacidade percentual de um motor para transformar energia seguindo os princípios da 2° lei 
  //da termodinâmica.
  var energiaDoTrabalho2 = 12;
  var energiaRecebida2 = 23;
  var capacidadePercentual = ((energiaDoTrabalho2 * 100)/(energiaRecebida2 * 100)*100);
  
  print('O resultado da capacidade percentual do motor é de $capacidadePercentual\%.');
}
